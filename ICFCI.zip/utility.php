<?php
error_reporting(1);
	function ExecuteQuery ($SQL)
	{	
		$con=mysql_connect ("localhost", "root","");
		mysql_select_db ("icfci",$con);
		
		$rows = mysql_query ($SQL);
		echo "Hii";
		mysql_close ();
		
		return $rows;
	}
	
	function ExecuteNonQuery ($SQL)
	{
		$con=mysql_connect ("localhost", "root","");
		mysql_select_db ("icfci",$con);
		
		$result = mysql_query ($SQL);
		echo "Hii";
		mysql_close ();
		
		return $result;
	}
?>