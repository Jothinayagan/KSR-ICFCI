<?php  
ob_start();
require("utility.php"); ?>

<?php
$name=$_POST['contactName'];
$dept=$_POST['dept'];
$year=$_POST['year'];
$college=$_POST['contactclg'];
$email=$_POST['contactEmail'];
$number=$_POST['contactNumber'];


$sql=" INSERT INTO reg(Name,Dept,Year,College,Email,Phone) values ('$name','$dept','$year','$college','$email','$number')";
//$sql="INSERT INTO reg(Name) values ('$fname')";
$result=ExecuteNonQuery ($sql);

if($result)
{
	echo "<h1> YOU ARE REGISTERED </h1> " ;
	echo "Redirecting...";
        header("refresh:2;url=index.php");
}
else
{
	echo "<h1> Register again </h1> " ;	
	echo "Redirecting...";
        header("refresh:2;url=index.html");
}
?> 	