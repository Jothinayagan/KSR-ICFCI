 
 <html>
 <head>
<style>
table, th, td {
    border: 1px solid black;
}
</style>



  </head>
 
 <?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "icfci";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM reg";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo "<table ><tr><th>ID</th><th>Name</th><th>Gender</th><th>Organisation</th><th>Category</th><th>Phone</th><th>Email id</th><th>Accomodation</th><th>Hostel/Hotel</th></tr>";
    // output data of each row
    while($row = $result->fetch_assoc()) {
        
echo "<tr><td>".$row["Sno"]."</td><td>".$row["Name"]."</td><td>".$row["Gender"]."</td><td>".$row["Organisation"]."</td><td>".$row["Category"]."</td><td>".$row["Phone"]."</td><td>".$row["Email"]."</td><td>".$row["Accomodation"]."</td><td>".$row["Accplace"]."</td></tr>";

		}
    echo "</table>";
} else {
    echo "0 results";
}
$conn->close();

?> </html>