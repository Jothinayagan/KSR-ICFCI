<?php
echo "Hiiii";
$g="gowtham";
$t='c';
echo '$g $t';
?>